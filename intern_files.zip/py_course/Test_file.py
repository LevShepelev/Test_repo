import numpy as np
from datetime import datetime
import time

h, v = np.meshgrid(np.arange(3)*3, np.arange(3)*2)
data = np.random.random((3, 3))
print(data)
x,y = np.indices(3,3)
h[x, y]    # horizontal coordinate
v[x, y]    # vertical coordinate
data[x, y]