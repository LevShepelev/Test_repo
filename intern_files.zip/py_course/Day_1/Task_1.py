n = int(input())
for number in range(1, int(n) + 1):
    if int(number) % 15 == 0:
         print("Fizz Buzz", end = '')
    elif int(number) % 5 == 0:
        print("Buzz", end = '')
    elif int(number) % 3 == 0:
        print("Fizz", end = '')
    else: 
        print(number, end = '')
    if (number < n):
        print(', ', end = '')