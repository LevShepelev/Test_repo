import operator
my_str = input()
n = int(input())
d = dict()
for i in range(0, len(my_str) - n + 1):
    if my_str.count(my_str[i:i + n]) > 1:
        d[my_str[i:i + n]] = my_str.count(my_str[i:i + n])
sorted_tuples = sorted(d.items(), key=operator.itemgetter(0))
sorted_dict = {k: v for k, v in sorted_tuples}
print(list(sorted_dict.keys()))