x = int(input())

def is_perfect(x):
    a = int(0)
    b = int(0)
    x = int(x)
    for i in range(0, 3):
        a += (x // 10 ** i) % 10
        b += (x // 10 ** (i + 3)) % 10
    if a == b:
        return True
    else:
        return False

nearest_number = int(0)
nearest_number_second = int(0)

for i in range(x, 999999 + 1):
    if is_perfect(i) == True:
        nearest_number = i
        break
for i in range(x, 100000, -1):
    if is_perfect(i) == True:
        nearest_number_second = i
        break
if (is_perfect(x) == True):
    print(x)
else:
    if nearest_number - x < x - nearest_number_second:
        print(nearest_number)
    else:
        print(nearest_number_second)

