import operator
my_str = input()
indicator = 0
for i in range(0, len(my_str)):
    if my_str.count(my_str[i:i + 1]) > 1:
        print("True")
        indicator = 1
        break
if indicator == 0:
    print("False")