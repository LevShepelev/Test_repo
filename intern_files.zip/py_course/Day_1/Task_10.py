import operator
my_str = input()
d = dict()
answer = dict()
for symb in my_str:
    d[symb] = 1
for symb in d.keys():
    max_str = 1
    for i in range(1, len(my_str) + 1):
        curr_str = symb * i
        if my_str.count(curr_str) > 0:
            max_str = len(curr_str)
    answer[symb] = max_str
sorted_tuples = sorted(answer.items(), key=operator.itemgetter(0))
sorted_dict = {k: v for k, v in sorted_tuples}
for a in sorted_dict.items():
    print(a[0], a[1])
