import operator
str_1 = input()
str_2 = input()
d = dict(zip(str_1, str_2))
for i in range(len(str_2), len(str_1)):
    d[str_1[i]] = None
sorted_tuples = sorted(d.items(), key=operator.itemgetter(1))
sorted_dict = {k: v for k, v in sorted_tuples}
print(list(d.items()))