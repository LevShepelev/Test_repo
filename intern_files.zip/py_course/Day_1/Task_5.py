(n, m) = map(int, input().split())
ans = ""
while n // m != 0:
    ans += str(n % m)
    n //= m
ans += str(n % m)
print(''.join(reversed(ans)))
