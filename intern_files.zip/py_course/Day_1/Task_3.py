(n, m) = map(int, input().split())
A = [[i * j for j in range(1, m + 1)] for i in range(1, n + 1)]
for line in A:
    print(*line)
