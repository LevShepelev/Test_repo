words = input().split()
out_str = ''.join(words)
max_word = max(words, key=lambda p: out_str.count(p) / len(words))
print(out_str.count(max_word) / len(words), end='')