def print_elem(n, piece):
    for i in range(0, n - 1): 
        print(piece, end = ' ')
    print(piece)

n = int(input())
print_elem(n, "   _~_   ")
print_elem(n, "  (o o)  ")
print_elem(n, " /  V  \\ ")
print_elem(n, "/(  _  )\\")
print_elem(n, "  ^^ ^^  ")
