log = open('input.txt')
lst = log.read().split('\n')
for s in lst:
    words = s.split(sep='\t')
    print(words[0][0:7], '.' * (80 - 7 - len(words[len(words) - 1])), words[len(words) - 1][0:len(words[len(words) - 1])], sep='')
