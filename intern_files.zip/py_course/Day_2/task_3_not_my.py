log = withdopen('input.txt', 'r')
log = log.read().split('\n') #readlines функция
for a in log
