s = input()

def is_palindrom(s):
    for i in range(0, len(s) // 2 + 1):
        if s[i] != s[len(s) - i - 1]:
            return False
    return True
    
if is_palindrom(s):
    print(0)
else:
    for i in range(0, len(s)):
        new_str = s
        for j in range(i, -1, -1):
            new_str += s[j]
        if is_palindrom(new_str):
            print(i + 1)
            break
