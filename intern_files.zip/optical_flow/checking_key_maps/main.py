import sys
import cv2
import numpy as np
import key_maps_lib as dl
import vector_field as vf
import argparse

parser = argparse.ArgumentParser(description='A tutorial of argparse!')
parser.add_argument("--left_folder", default="/home/lev/internship/dataset/training/image_0/", help="This is the path to folder with left images variable")
parser.add_argument("--right_folder", default="/home/lev/internship/dataset/training/image_1/", help="This is the path to folder with right images variable")
parser.add_argument("--disp_occ", default="/home/lev/internship/dataset/training/disp_occ/", help="This is the path to folder with disparity maps")
args = parser.parse_args()

images = dl.read_images(dl.dataloader(args.left_folder, args.right_folder, args.disp_occ))
for curr_im_tuple in images:
    pixel_counter = int(0)
    bad_pixel_counter = [0, 0, 0]
    restored_image = dl.image_transport(curr_im_tuple)
    cv2.imwrite("./images_after_transformation/" + "restored_" + curr_im_tuple[3].split('image_0/')[1], restored_image)


