import sys
import os
import os.path
import numpy as np
import cv2
from numpy import diff
import key_maps_lib as dl
from statistics import mean

def calculate_distance(key_predict, key_truth, non_occluded):
    if non_occluded == False:
        difference = np.abs(key_truth - key_predict)
        return np.count_nonzero(np.where(difference >= 3, 1, 0)) / np.size(difference)
    else:
        mask = np.where(key_truth > 0, 1, 0)
        difference = np.abs(key_truth - key_predict * mask)
        return np.count_nonzero(np.where(difference >= 3, 1, 0)) / np.size(np.where(key_truth > 0))

def mean_distance_for_images_set(key_predict_folder, key_truth_folder, non_occluded):
    file_lst_predict = os.listdir(key_predict_folder)
    file_lst_truth = os.listdir(key_truth_folder)
    list_of_distances = list()
    for map in file_lst_predict:
        disp_map_predict = cv2.imread(key_predict_folder + map, cv2.IMREAD_UNCHANGED)
        if map not in file_lst_truth:
            print("Something wrong with data", map, "exists in predict folder, but doesnt exists in ground_truth_folder")
            exit(1)
        disp_map_truth = cv2.imread(key_truth_folder + map, cv2.IMREAD_UNCHANGED)
        list_of_distances.append(calculate_distance(disp_map_predict, disp_map_truth, non_occluded))
    return mean(list_of_distances) * 100

#example: print(mean_distance_for_images_set("../../dataset/training/disp_noc/", "../../dataset/training/disp_occ/", non_occluded=True))
