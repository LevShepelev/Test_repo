import matplotlib.pyplot as plt
import numpy as np
import cv2

def draw_vector_field(image):
    u, v, bit_existency = cv2.split(image[2])
    vect_field = list()
    for i in range(0, image[2].shape[0]):
        for j in range(0, image[2].shape[1]):
            if bit_existency[i][j] == 1:
                vect_field.append((i, j, u[i][j], v[i][j]))
    X, Y, U, V = zip(*vect_field)
    print(vect_field[0])
    plt.figure()
    ax = plt.gca()
    ax.quiver(X, Y, U, V, angles='xy', scale_units='xy', scale=1)
    ax.set_xlim([0, 1500])
    ax.set_ylim([0, 400])
    plt.draw()
    plt.show()