import os
import os.path
import numpy as np
import cv2

IMG_EXTENSIONS = [
    '.jpg', '.JPG', '.jpeg', '.JPEG',
    '.png', '.PNG', '.ppm', '.PPM', '.bmp', '.BMP',
]

def is_image_file(filename):
    return any(filename.endswith(extension) for extension in IMG_EXTENSIONS)

def dataloader(filepath_left, filepath_right, keypath):
    file_lst_left = os.listdir(filepath_left)
    file_lst_right = os.listdir(filepath_right)
    file_lst_keys = os.listdir(keypath)
    list_of_tuples = list()
    for img in file_lst_left:
        if img.find('_10') > 0:
            list_of_tuples.append((filepath_left + img, filepath_right + img, keypath + img))
            if img not in file_lst_right:  
                print("Something wrong with dataset exist", img ,"but right version doesnt exit")
                exit(-1)
            if img not in file_lst_keys:
                print("Something wrong with dataset, 10_image exist, but key_map for image doesnt exit")
                exit(-1)
    
    return list_of_tuples
    

def read_images(list_of_tuples):
    images = list()
    for elem in list_of_tuples:
        img_first = cv2.imread(elem[0], cv2.IMREAD_GRAYSCALE)
        img_second = cv2.imread(elem[1], cv2.IMREAD_GRAYSCALE)
        disp_map = cv2.imread(elem[2], cv2.IMREAD_UNCHANGED)
        disp_map[...] = disp_map[...].astype(float) / 256.0
        images.append((img_first, img_second, disp_map, elem[0]))
    return images

def image_transport(curr_im_tuple):
    x_old, y_old = np.meshgrid(np.arange(0, curr_im_tuple[0].shape[0]), np.arange(0, curr_im_tuple[0].shape[1]))
    x_old = np.transpose(x_old)
    y_old = np.transpose(y_old)
    shift = np.where(curr_im_tuple[2] > 0, curr_im_tuple[2], 0)
    x_new = x_old + shift
    x_new = np.where(x_new < curr_im_tuple[0].shape[0], x_new, 0)
    restored_image = np.arange(curr_im_tuple[0].shape[0] * curr_im_tuple[0].shape[1]).reshape(curr_im_tuple[0].shape[0], curr_im_tuple[0].shape[1])
    restored_image[x_new, y_old] = curr_im_tuple[0][x_old, y_old]
    print("bad pixel_percentage:", (1 - np.count_nonzero(shift) / np.size(shift)) * 100)
    return restored_image