//Compile g++ Calculate_pixel_error.cpp  -std=c++17 -lpng -lstdc++fs

#include "io_disp.h"
#include <experimental/filesystem>
namespace fs = std::experimental::filesystem;
 

int main() {
    std::string path = "/home/lev/internship/dataset/training/disp_noc/";
    for (auto & p : fs::directory_iterator(path)) {
        DisparityImage image = DisparityImage(p.path());
        int counter = 0;
        for (int i = 0; i < image.width_; i++) {
            for (int j = 0; j < image.height_; j++) {
                if (!image.isValid(i, j))
                    counter++;
            }
        }
        std::cout << p.path() << " Bad pixel number: " << counter / ((double) image.width_ * image.height_) << std::endl;
    }
}