from PIL import Image
import os
import os.path
import numpy as np
import cv2
import imageio
import key_maps_lib as dl
import imageio.v2 as imageio

path = "/home/lev/internship/dataset/training/disp_noc"
path_left = "/home/lev/internship/dataset/training/image_0/"
path_right = "/home/lev/internship/dataset/training/image_1/"
key_lst = os.listdir(path)
for image_name in key_lst:
    counter = int(0)
    key_cv = cv2.imread(path + '/' + image_name, cv2.IMREAD_UNCHANGED)
    key = imageio.imread(path + '/' + image_name)

    image_left = imageio.imread(path_left + image_name)
    image_left_cv = cv2.imread(path_left + image_name, cv2.IMREAD_GRAYSCALE)

    image_right = imageio.imread(path_right + image_name)
    image_right_cv = cv2.imread(path_right + image_name, cv2.IMREAD_GRAYSCALE)
    
    for string in key:
        for val in string:
            if val == 0:
                counter += 1
            else:
                val = val.astype(float) / 256.0
    for i in range(0, key_cv.shape[0]):
        for j in range(0, key_cv.shape[1]):
            if key_cv[i][j] == 0:
                counter += 1
            else:
                key_cv[i][j] = key_cv[i][j].astype(float) / 256.0
    restored_image = dl.image_transport((image_left, image_right, key))
    restored_image_cv = dl.image_transport((image_left_cv, image_right_cv, key_cv))
    cv2.imwrite("/home/lev/internship/optical_flow/checking_key_maps/images_after_transformation_1/" + "restored_" + image_name, restored_image)
    cv2.imwrite("/home/lev/internship/optical_flow/checking_key_maps/images_after_transformation_2/" + "restored_" + image_name, restored_image)