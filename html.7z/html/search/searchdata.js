var indexSectionsWithContent =
{
  0: "bcflmos",
  1: "s",
  2: "o",
  3: "bcfm",
  4: "ls"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

