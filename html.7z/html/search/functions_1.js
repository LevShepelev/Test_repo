var searchData=
[
  ['cmp1_12',['cmp1',['../onegin_01try4_8cpp.html#aaac7e2e355969549a4a0a11af2825626',1,'onegin try4.cpp']]],
  ['cmp2_13',['cmp2',['../onegin_01try4_8cpp.html#ae17a96b13e4e179fc88af7070cf11728',1,'onegin try4.cpp']]]
];
