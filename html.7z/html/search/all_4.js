var searchData=
[
  ['main_5',['main',['../onegin_01try4_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'onegin try4.cpp']]]
];
