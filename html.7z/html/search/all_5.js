var searchData=
[
  ['onegin_20try4_2ecpp_6',['onegin try4.cpp',['../onegin_01try4_8cpp.html',1,'']]]
];
